using Microsoft.AspNetCore.Mvc.RazorPages;

namespace VCEWeb.Pages
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}