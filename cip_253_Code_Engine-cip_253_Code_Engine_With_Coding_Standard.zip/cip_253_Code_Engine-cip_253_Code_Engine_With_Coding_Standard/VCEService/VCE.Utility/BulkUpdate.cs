﻿namespace VCE.Utility
{
    public class BulkUpdate
    {
    }
}