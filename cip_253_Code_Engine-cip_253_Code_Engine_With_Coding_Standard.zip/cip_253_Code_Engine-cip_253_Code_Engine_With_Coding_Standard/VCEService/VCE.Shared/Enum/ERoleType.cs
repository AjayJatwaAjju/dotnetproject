﻿namespace SIPL.Shared.Enum
{
    public enum ERoleType
    {
        User = 1,
        Admin = 2,
        Agent = 3,
        Partner = 4,
        StaffMember = 5,
        Sales = 6
    }
}