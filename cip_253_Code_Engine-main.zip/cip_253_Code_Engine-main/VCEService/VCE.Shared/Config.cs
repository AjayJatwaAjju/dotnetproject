﻿using System.Configuration;

namespace VCE.Shared
{
    public static class Config
    {
        public static string OAppPath = ConfigurationManager.AppSettings["ProjectName"].Trim();
        public static int ApplicationTimeOut = 360;
        public static string DatabaseName = "VCE";
        public static string Host = "abc.xyz.net";
        public static int port = 587;
        public static string UserName = "connect@support.com";
        public static string Password = "support";

        //getting default No Image Path 
        public static string NoImagePath()
        {
            return OAppPath + "/Photo/" + "ExpenseNoImagePath.png";
        }
    }
}
