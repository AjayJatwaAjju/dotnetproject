﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VCE.Business
{
    public class DatabaseService
    {
    }
}
