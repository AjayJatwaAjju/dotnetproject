﻿using System;
using System.Web;
using System.Data;
using VCE.DAL;

namespace VCE.Business
{
    ///--------------------------------------------------------------------------
    /// <summary>
    /// Summary description for TableService.
    /// </summary> 
    /// <remarks>
    /// Created On:- 04/05/2023
    /// Created By:- Menter
    /// Purpose:- This class will provide service for database Table. 
    /// </remarks>
    ///---------------------------------------------------------------------------
    public class TableService
    {
      

       TableInfo oTableInfo = new TableInfo();
       //Creating a TableProvider object
       TableProvider oTableProvider = new TableProvider();

        /// <summary>
        /// This will return all Table records based on applied condition.
        /// </summary>
        /// <remarks>
        /// <param name="whereCondition">Passing condition for filtering Table records.</param>
        /// <param name="orderBy">Passing OrderBy.</param>
        /// </remarks>
        public DataTable GetTableInfo(string whereCondition, string orderBy)
        {
            return oTableProvider.GetTableInfo(whereCondition, orderBy);
        }
    }
}
