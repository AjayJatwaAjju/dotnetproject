﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCE.DAL;
using VCE.Shared.Dictionary;

namespace VCE.Business.Repository
{
    public class LookupRepository
    {
        public async virtual Task<IDictionary<string, int>> GetDatabaseTypes()
        {
            DatabaseType databaseType = new DatabaseType();
            var result =await databaseType.GetDatabaseType();
            return result;
        }
        public async virtual Task<IDictionary<string, string>> GetDatabases(string DatabaseType, string DataSource, String UserName, string UserPassword, string Database = "master")
        {
            DatabaseProvider databaseProvider = new DatabaseProvider();
            var result = await databaseProvider.GetDatabases(DatabaseType, DataSource, UserName, UserPassword, Database);

            return result;
        }
        public async virtual Task<IDictionary<string, string>> GetDatabases(string DatabaseType, string connectionstring)
        {
            DatabaseProvider databaseProvider = new DatabaseProvider();
            var result = await databaseProvider.GetDatabases(DatabaseType, connectionstring);

            return result;
        }
        public async virtual Task<IDictionary<string, string>> GetTableList(string DatabaseType, string connectionstring)
        {
            TableProvider tableProvider = new TableProvider();
            var result = await tableProvider.GetTableList(DatabaseType, connectionstring);

            return result;
        }
        public async virtual Task<DataTable> GetTableDetails(string DatabaseType, string connectionstring, string TableName)
        {
            TableProvider tableProvider = new TableProvider();
            var result = await tableProvider.GetTableDetails(DatabaseType, connectionstring, TableName);

            return result;
        }
        public async virtual Task<DataTable> GetTableData(string TableName, string connectionstring, string whereCondition, string orderBy, string pageSize, string pageStart, string DatabaseType, DataTableSearchData inputjson)
        {
            TableProvider tableProvider = new TableProvider();
            var result = await tableProvider.GetTableData(TableName, connectionstring, whereCondition, orderBy, pageSize, pageStart, DatabaseType, inputjson);

            return result;
        }
        public async virtual Task<string> GetScript(string Databasetype, string FileName)
        {
            TableProvider tableProvider = new TableProvider();
            var result = await tableProvider.GetScript(Databasetype, FileName);

            return result;
        }
        public async virtual Task<string> GetFileString(string FileName)
        {
            TableProvider tableProvider = new TableProvider();
            var result = await tableProvider.GetFileString(FileName);

            return result;
        }

        
    }
}
