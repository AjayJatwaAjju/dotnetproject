﻿using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;
using VCE.DAL.Helpers;
using VCE.Shared.Dictionary;

namespace VCE.DAL
{
    ///--------------------------------------------------------------------------
    /// <summary>
    /// Summary description for TableProvider.
    /// </summary> 
    /// <remarks>
    /// Created On:- 04/05/2023
    /// Created By:- Menter
    /// Purpose:- This is for performing actions in database Tables
    /// </remarks>
    ///---------------------------------------------------------------------------

    public class TableProvider
    {
        #region Methods   
        /// <summary>
        /// This will return all Table records based on applied condition.
        /// </summary>
        /// <remarks>
        /// <param name="whereCondition">Passing condition for filtering Table records.</param>
        /// <param name="orderBy">Passing OrderBy.</param>
        /// </remarks>
        public DataTable GetTableInfo(string whereCondition, string orderBy)
        {
            var param = new SqlParameter[2];
            param[0] = new SqlParameter();
            param[0].ParameterName = "@whereCondition";
            param[0].Value = whereCondition;

            param[1] = new SqlParameter();
            param[1].ParameterName = "@orderBy";
            param[1].Value = orderBy;

            var ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "spGetTable", param);
            if (ds != null && ds.Tables.Count > 0)
            {
                return ds.Tables[0];
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="DatabaseType"></param>
        /// <param name="DataSource"></param>
        /// <param name="UserName"></param>
        /// <param name="UserPassword"></param>
        /// <param name="Database"></param>
        /// <returns></returns>
        public async virtual Task<IDictionary<string, string>> GetTableList(string DatabaseType, string connectionstring)
        {
            connectionstring = Base65EncodeDeCodeHelper.Base64Decode(connectionstring);
            DataSet ds = new DataSet();
            if (DatabaseType == "1")
            {
                ds = SqlHelper.ExecuteDataset(connectionstring, CommandType.Text, "SELECT TABLE_SCHEMA+'.'+TABLE_NAME TABLE_NAME1,TABLE_SCHEMA+'.'+TABLE_NAME TABLE_NAME FROM INFORMATION_SCHEMA.TABLES where TABLE_TYPE='BASE TABLE' order by 1;");
            }
            else
            {
                ds = PostgreSQLHelper.ExecuteDataset(connectionstring, CommandType.Text, "SELECT table_schema ||'.'||table_name \"TABLE_NAME1\",table_schema ||'.'||table_name \"TABLE_NAME\"  FROM information_schema.tables WHERE 1=1  and table_schema not in ('pg_catalog','information_schema') AND table_type='BASE TABLE';");
            }

            var result = new Dictionary<string, string>();
            result = ds.Tables[0].AsEnumerable()
                                 .ToDictionary<DataRow, string, string>(
                                    row => row.Field<string>(0),
                                    row => row.Field<string>(1)
                                );
            return result;
        }
        public async virtual Task<DataTable> GetTableDetails(string DatabaseType, string connectionstring, string TableName)
        {
            connectionstring = Base65EncodeDeCodeHelper.Base64Decode(connectionstring);
            string sqlScript = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "sqlScript\\GetTableInfo.sql");
            if (DatabaseType == "2")
            {
                sqlScript = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "PgsqlScript\\GetTableInfo.sql");
                sqlScript = sqlScript.Replace("Yourtableschema", TableName.Split('.')[0]);
            }
            sqlScript = sqlScript.Replace("YourTableName", TableName.Split('.')[1]);
            DataSet ds = new DataSet();
            if (DatabaseType == "1")
            {
                ds = SqlHelper.ExecuteDataset(connectionstring, CommandType.Text, sqlScript);
            }
            else
            {
                ds = PostgreSQLHelper.ExecuteDataset(connectionstring, CommandType.Text, sqlScript);
            }
            var result = ds.Tables[0];

            return result;
        }


        public async virtual Task<DataTable> GetTableData(string TableName, string connectionstring, string whereCondition, string orderBy, string pageSize, string pageStart, string DatabaseType, DataTableSearchData inputjson)
        {
            try
            {
                var result = new DataTable();
                connectionstring = Base65EncodeDeCodeHelper.Base64Decode(connectionstring);
                if (DatabaseType == "1")
                {
                    string sqlScript = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "sqlScript\\GetTableData.sql");


                    //sqlScript = sqlScript.Replace("@ReplaceWhereCondition", whereCondition);
                    sqlScript = sqlScript.Replace("@ReplaceOrderBy", orderBy);
                    sqlScript = sqlScript.Replace("@ReplacePageStart", pageStart);
                    sqlScript = sqlScript.Replace("@ReplacePageSize", pageSize);
                    sqlScript = sqlScript.Replace("@ReplaceTableName", TableName);

                    SqlParameter[] parameter = new SqlParameter[1];
                    parameter[0] = new SqlParameter("@whereCondition", SqlDbType.VarChar, 50000);
                    parameter[0].Value = whereCondition;


                    DataSet ds = SqlHelper.ExecuteDataset(connectionstring, CommandType.Text, sqlScript, parameter);
                    result = ds.Tables[0];
                }
                else if (DatabaseType == "2")
                {
                    string sqlScript = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "pgsqlScript\\GetTableData.sql");
                    sqlScript = sqlScript.Replace("@replaceWhereConditions", whereCondition);
                    //sqlScript = sqlScript.Replace("@ReplaceOrderBy", orderBy);
                    sqlScript = sqlScript.Replace("@pkid", inputjson.pkid);
                    sqlScript = sqlScript.Replace("@replaceinputJson","["+JsonConvert.SerializeObject(inputjson)+ "]");
                    sqlScript = sqlScript.Replace("@ReplaceTableName", TableName);


                    DataSet ds = PostgreSQLHelper.ExecuteDataset(connectionstring, CommandType.Text, sqlScript);
                    result = ds.Tables[0];
                }
                return result;
            }

            catch (Exception ex)
            {

            }
            return null;
        }
        public async virtual Task<string> GetScript(string Databasetype, string FileName)
        {
            string sqlScript = await File.ReadAllTextAsync(AppDomain.CurrentDomain.BaseDirectory + ((Databasetype == DatabaseTypes.MicrosoftSQLServer.ToString()) ? "sqlScript\\" : "PgSqlScript\\") + FileName);
            return sqlScript;
        }
        public async virtual Task<string> GetFileString(string FileName)
        {
            string sqlScript = await File.ReadAllTextAsync(AppDomain.CurrentDomain.BaseDirectory + FileName);
            return sqlScript;
        }


        #endregion
    }

    ///--------------------------------------------------------------------------
    /// <summary>
    /// Summary description for TableInfo.
    /// </summary> 
    /// <remarks>
    /// Created On:- 04/05/2023
    /// Created By:- Menter
    /// Purpose:- This class will contain the property of database Table.
    /// </remarks>
    ///---------------------------------------------------------------------------
    public class TableInfo
    {
        #region Variable  Declaration
        public string TableName { get; set; }
        public string TableDetails { get; set; }
        public bool IsActive { get; set; }
        public DateTime CratedDate { get; set; }
        #endregion
    }
}
