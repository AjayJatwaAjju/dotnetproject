﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VCE.DAL.Helpers;

namespace VCE.DAL
{
    public class DatabaseProvider
    {
        public async virtual Task<IDictionary<string, string>> GetDatabases(string DatabaseType, string DataSource, String UserName, string UserPassword, string Database = "master")
        {
            string connectionstring = SqlHelper.createConnectionString(DataSource, Database, UserName, UserPassword);

            DataSet ds = SqlHelper.ExecuteDataset(connectionstring, CommandType.Text, "SELECT name, database_id, create_date  FROM sys.databases order by 1;");

            var result = new Dictionary<string, string>();
            result = ds.Tables[0].AsEnumerable()
                                 .ToDictionary<DataRow, string, string>(
                                    row => row.Field<string>(0),
                                    row => row.Field<string>(0)
                                );
            return result;
        }
        public async virtual Task<IDictionary<string, string>> GetDatabases(string DatabaseType, string connectionstring)
        {
            connectionstring = Base65EncodeDeCodeHelper.Base64Decode(connectionstring);
            DataSet ds = new DataSet();
            if (DatabaseType == "1")
            {
                ds = SqlHelper.ExecuteDataset(connectionstring, CommandType.Text, "SELECT name, database_id, create_date  FROM sys.databases order by 1;");
            }
            else
            {
                ds = PostgreSQLHelper.ExecuteDataset(connectionstring, CommandType.Text, "SELECT datname \"name\",oid database_id FROM pg_database /*where has_database_privilege('PMeravat', datname, 'CONNECT')=true*/ order  by 1;");
            }
            var result = new Dictionary<string, string>();
            result = ds.Tables[0].AsEnumerable()
                                 .ToDictionary<DataRow, string, string>(
                                    row => row.Field<string>(0),
                                    row => row.Field<string>(0)
                                );
            return result;
        }
        
    }
}
