﻿let ConnectionStrings = {
    1: "Data Source=@DataSource; Database=@Database; User ID=@UserID; Connection Timeout=500; Password=@Password;",
    2: "Server=@DataSource;Port=5432;Database=@Database;User Id=@UserID;Password=\"@Password\";CommandTimeout=180"
}
function GetDatabaseTypes(cb_func) {

    $.ajax({
        type: "Get",
        url: "api/lookup/DatabaseTypes",
        //data: { project_number: projectNumber, parent_number: parentENumber },

        // ------v-------use it as the callback function
        success: cb_func,
        error: function (request, error) {
            $('#preloader').show();
            alert('An error occurred attempting to get new database type');
            // console.log(request, error);
        }
    });
}
function GetDatabasesOld(DatabaseType, DataSource, UserName, UserPassword, cb_func) {

    $.ajax({
        type: "Get",
        url: "api/lookup/Databases?DatabaseType=" + DatabaseType + "&DataSource=" + DataSource + "&UserName=" + UserName + "&UserPassword=" + UserPassword,
        //data: { project_number: projectNumber, parent_number: parentENumber },
        // ------v-------use it as the callback function
        success: cb_func,
        error: function (request, error) {
            $('#preloader').show();
            alert('An error occurred attempting to get databases');
            // console.log(request, error);
        }
    });
}

function GetDatabases(DatabaseType, DataSource, UserName, UserPassword, cb_func) {


    let ConnectionString = GetConnectionString(DataSource, UserName, UserPassword, DatabaseType == "1" ? 'master' : 'postgres');

    $.ajax({
        type: "Get",
        url: "api/lookup/Databases?DatabaseType=" + DatabaseType,
        //data: { project_number: projectNumber, parent_number: parentENumber },

        headers: { 'UTI5dWJtVmpkR2x2YmxOMGNtbHVadz09': ConnectionString },
        // ------v-------use it as the callback function
        success: cb_func,
        error: function (request, error) {
            $('#preloader').show();
            alert('An error occurred attempting to get databases');
            // console.log(request, error);
        }
    });
}
function GetTableList(DatabaseType, DataSource, UserName, UserPassword, textDatabase, cb_func) {

    let ConnectionString = GetConnectionString(DataSource, UserName, UserPassword, textDatabase);
    $.ajax({
        type: "Get",
        url: "api/lookup/TableList?DatabaseType=" + DatabaseType,
        headers: { 'UTI5dWJtVmpkR2x2YmxOMGNtbHVadz09': ConnectionString },

        // ------v-------use it as the callback function
        success: cb_func,
        error: function (request, error) {
            $('#preloader').show();
            alert('An error occurred attempting to get new tablelist');
            // console.log(request, error);
        }
    });
}
function GetTableDetails(DatabaseType, DataSource, UserName, UserPassword, textDatabase, TableName, cb_func) {

    let ConnectionString = GetConnectionString(DataSource, UserName, UserPassword, textDatabase);
    $.ajax({
        type: "Get",
        url: "api/lookup/TableDetail?DatabaseType=" + DatabaseType
            + "&TableName=" + TableName,
        headers: { 'UTI5dWJtVmpkR2x2YmxOMGNtbHVadz09': ConnectionString },

        // ------v-------use it as the callback function
        success: cb_func,
        error: function (request, error) {
            $('#preloader').show();
            alert('An error occurred attempting to get tabledetail');
            // console.log(request, error);
        }
    });
}
function GetApiList() {

    return {
        "Controller": 1,
        "ASHX": 2,
        /*"ASMX": 2*/
    }

}

function GetConnectionString(DataSource, UserName, UserPassword, Database) {

    let ConnectionString = ConnectionStrings[$('#SelectDatabaseType').val()];
    ConnectionString = ConnectionString.replace('@DataSource', DataSource);
    ConnectionString = ConnectionString.replace('@UserID', UserName);
    ConnectionString = ConnectionString.replace('@Password', UserPassword);
    ConnectionString = ConnectionString.replace('@Database', Database);
    ConnectionString = Base64.encode(ConnectionString);

    return ConnectionString;

}
var LookupServiceSettings = {
    "defaultSchemaMSSQL": "dbo",
    "updateTableMSSQL": "sqlScript\\spUpdateTableData.sql",
    "insertIntoTableMSSQL": "sqlScript\\spInsertTableData.sql",
    "deleteFromTableMSSQL": "sqlScript\\spDeleteTableData.sql",
    "getTableInfoMSSQL": "sqlScript\\spGetTable.sql",
    "setOprationsMSSQL": "sqlScript\\spSetTable.sql",
    "getTableInfoByIdMSSQL": "sqlScript\\spGetTableDataByID.sql",
    "EntityProviderMSSQL": "classFile\\EntityProvider.txt", 

    "defaultSchemaPostgreSQL": "public",
    "EntityProviderPostgreSQL": "classFile\\EntityProviderPgSql.txt",   
    "updateTablePostgreSQL": "PgSqlScript\\spUpdateTableData.sql",
    "insertIntoTablePostgreSQL": "PgSqlScript\\spUpdateTableData.sql",
    "deleteFromTablePostgreSQL": "PgSqlScript\\spUpdateTableData.sql",
    "getTableInfoPostgreSQL": "PgSqlScript\\spGetTable.sql",
    "setOprationsPostgreSQL": "PgSqlScript\\spSetTable.sql",
    "getTableInfoByIdPostgreSQL": "PgSqlScript\\spUpdateTableData.sql",

    "RequestHandler": "classFile\\RequestData.ashx.txt",
    "DataTableSearchData": "classFile\\DataTableSearchData.txt",
    "EntityController": "classFile\\EntityController.txt",
    "htmlDatatableExample": "HtmlFiles\\DatatableExample.html",
    "javascriptPageSample": "jsFiles\\PageSample.js",
    "javascriptPageSampleRshx": "jsFiles\\PageSample.js",
}
