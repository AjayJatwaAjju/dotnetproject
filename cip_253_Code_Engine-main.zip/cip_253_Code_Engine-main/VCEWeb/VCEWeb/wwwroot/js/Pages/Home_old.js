﻿
var CodeSettings = {};

$(document).ready(function () {
    GetDatabaseTypes(bindDatabaseTypes);
    //$("#sectionFrontendSelection").hide();
    //$("#sectionBackendSelection").hide();
    //$("#sectionGenerateSelection").hide();
    //$("#sectionDatabaseSelection").hide();
    //$("#sectionFilterOptionsSelection").hide();

    $("#tabsStoredProcedure").tabs(tabsStoredProcedureSetting);
    $("#tabsFunctions").tabs(tabsFunctionsSetting);
    $("#tabsHtml").tabs();
    //$('#txtServerName').val('192.168.61.178');
    //$('#textUserName').val('rrdba');
    //$('#textPassword').val('Vision@2019');
    $('#txtServerName').val('192.168.61.227');
    $('#textUserName').val('PMeravat');
    $('#textPassword').val('123456789!');
    bindApiType();

    CodeSettings = {
        "ApiType": $('#SelectApiType').val(),
        "GridType": $('#SelectGridType').val(),
        "bSort": $('#DTE_Sorting')[0].checked,
        "searching": $('#DTE_Searching')[0].checked,
        "bServerSide": $('#DTE_bServerSide')[0].checked,
        "bInfo": $('#DTE_bInfo')[0].checked,
        "sScrollX": $('#DTE_ScrollX')[0].checked,
        "sScrollY": $('#DTE_ScrollY')[0].checked,
        "bPaginate": $('#DTE_Paginate')[0].checked,
        "aLengthMenu": $('#aLengthMenu').val(),
    }
});
function bindDatabaseTypes(data) {
    //console.log(cb_func);
    bindSelect(data, '#SelectDatabaseType', { "Select Server Type": 0 }, 2);
}
$('#ConnectDatabase').click(function (s) {
    ConnectDatabase(false);
});

function canConnectDatabase() {
    var result = true;

    if ($('#SelectDatabaseType').val() == "0") {
        result = false;
        $('#SelectDatabaseType').addClass("text-danger is-invalid");
        $('#SelectDatabaseType').attr('title', 'Select Server Type')
    }
    else {
        $('#SelectDatabaseType').removeClass("text-danger is-invalid");
        $('#SelectDatabaseType').attr('title', '')
    }
    if ($('#txtServerName').val() == "") {
        result = false;
        $('#txtServerName').addClass("text-danger is-invalid");
        $('#txtServerName').attr('title', 'Enter Server Name')
    }
    else {
        $('#txtServerName').removeClass("text-danger is-invalid");
        $('#txtServerName').attr('title', '')
    }
    if ($('#textUserName').val() == "") {
        result = false;
        $('#textUserName').addClass("text-danger is-invalid");
        $('#textUserName').attr('title', 'Enter Login Id')
    }
    else {
        $('#textUserName').removeClass("text-danger is-invalid");
        $('#textUserName').attr('title', '')
    }
    if ($('#textPassword').val() == "") {
        result = false;
        $('#textPassword').addClass("text-danger is-invalid");
        $('#textPassword').attr('title', 'Enter Password')
    }
    else {
        $('#textPassword').removeClass("text-danger is-invalid");
        $('#textPassword').attr('title', '')
    }

    return result
}


$('#selectDatabase').change(function (s) {
    if ($('#selectDatabase').val() == "0") {
        $('#selectDatabase').addClass("text-danger is-invalid");
        $('#selectDatabase').attr('title', 'Please Select Database');
        bindSelect([], '#SelectTable', { "Select Table": 0 }, 0);
    }
    else {
        $('#selectDatabase').removeClass("text-danger is-invalid");
        $('#selectDatabase').attr('title', '')

        DatabaseType = $('#SelectDatabaseType').val();
        txtServerName = $('#txtServerName').val();
        textUserName = $('#textUserName').val();
        textPassword = $('#textPassword').val();
        textDatabase = $('#selectDatabase').val();
        $('#preloader').show();
        GetTableList(DatabaseType, txtServerName, textUserName, textPassword, textDatabase, function (data) {
            if (!data.isError) {
                bindSelect(data.data, '#SelectTable', { "Select Table": 0 }, 'public.base_export');
                $('#SelectTable').change();
            }
            else {
                bindSelect([], '#SelectTable', { "Select Table": 0 }, 0);
                $.alert({ title: 'Error!', content: data.error });
            }
            $('#preloader').hide();
        });
    }
});
$('#SelectTable').change(function (s) {
    if ($('#SelectTable').val() == "0") {
        $('#SelectTable').addClass("text-danger is-invalid");
        $('#SelectTable').attr('title', 'Please Select Table')
    }
    else {
        $('#SelectTable').removeClass("text-danger is-invalid");
        $('#SelectTable').attr('title', '')
    }
});
var tablecolumn = [];
var tablecolumnData = [];
function GenerateCode() {

    tablecolumn = [];
    $("#tabsStoredProcedure").tabs("option", "active", 1);
    $("#tabsStoredProcedure").tabs("option", "active", 0);
    $("#tabsFunctions").tabs("option", "active", 1);
    $("#tabsFunctions").tabs("option", "active", 0);
    controlshtml = "";
    $('#TableDetails tbody tr').each(function (key, data) {
        var samplecontrolhtml = '<div class="col-md-6"><div class="form-group"><div class="form-group"><label for="@ColumnName">@ColumnName @isRequired</label>@inputcontrol</div></div></div>';
        data1 = $('#TableDetails').DataTable().rows(data).data()[0];
        var alltd = $(data).find('td');
        var newcolumn = {
            title: alltd[0].innerText,
            data: alltd[0].innerText,
            "sWidth": "140px",
            "sClass": "text-right " + alltd[0].innerText,
            datatype: $(alltd[1]).find('select').val(),
            SqlDatatype: $(alltd[1]).find('select').val(),
            mRender: dataTablerender,
            "@mRender": "@dataTablerender",
            bVisible: $(alltd[4]).find('input')[0].checked,
            is_nullable: $(alltd[2]).find('input')[0].checked,
            primaryKey: data1.primaryKey
        }
        tablecolumn.push(newcolumn);
        if (!newcolumn.is_nullable) {
            samplecontrolhtml = samplecontrolhtml.replaceAll("@isRequired", '<span class="required">*</span>');
        }
        else {
            samplecontrolhtml = samplecontrolhtml.replaceAll("@isRequired", '');
        }
        if ((!data1.primaryKey && data1.iseditable) || !data1.is_nullable) {
            if (newcolumn.datatype == "text" || newcolumn.datatype == "integer" || newcolumn.datatype == "Phone" || newcolumn.datatype == "Email") {
                samplecontrolhtml = samplecontrolhtml.replaceAll("@inputcontrol", '<input type="text" class="form-control" id="DTE_@ColumnName" name="@ColumnName" placeholder="Enter @ColumnName">');
            }
            else if (newcolumn.datatype == "Password") {
                samplecontrolhtml = samplecontrolhtml.replaceAll("@inputcontrol", '<input type="password" class="form-control" id="DTE_@ColumnName" name="@ColumnName" placeholder="Enter @ColumnName">');
            }
            else if (newcolumn.datatype == "date") {
                samplecontrolhtml = samplecontrolhtml.replaceAll("@inputcontrol", '<input type="text" class="form-control" id="DTE_@ColumnName" name="@ColumnName" placeholder="MM/dd/yyyy">');
            }
            else if (newcolumn.datatype == "checkbox" || newcolumn.datatype == "bit") {
                samplecontrolhtml = samplecontrolhtml.replaceAll("@inputcontrol", '<div class="switch"><input type="checkbox" id="DTE_@ColumnName" checked="checked"><span class="slider round"></span></div>');
            }
            else if (newcolumn.datatype == SqlToDtDataTypeMaping.drop_down) {
                samplecontrolhtml = samplecontrolhtml.replaceAll("@inputcontrol", '<Select id="DTE_@ColumnName" class="form-control"><option value="0">Select @ColumnName</option></Select>');
            }
            else if (newcolumn.datatype == SqlToDtDataTypeMaping.hidden) {
                samplecontrolhtml = samplecontrolhtml.replaceAll("@inputcontrol", '<input type="hidden" class="form-control" id="DTE_@ColumnName" name="@ColumnName" placeholder="MM/dd/yyyy">');
                samplecontrolhtml = samplecontrolhtml.replaceAll("col-md-6", 'col-md-6 hiddden');
            }
            else {
                samplecontrolhtml = samplecontrolhtml.replaceAll("@inputcontrol", '<input type="text" class="form-control" id="DTE_@ColumnName" name="@ColumnName" placeholder="Enter @ColumnName">');
            }

        }
        else {
            samplecontrolhtml = samplecontrolhtml.replaceAll("@inputcontrol", '<input type="text" class="form-control" id="DTE_@ColumnName" name="@ColumnName" placeholder="Enter @ColumnName">');
        }
        if (data1.primaryKey || newcolumn.datatype == SqlToDtDataTypeMaping.hidden) {
            samplecontrolhtml = samplecontrolhtml.replaceAll("col-md-6", 'col-md-6 hiddden');
        }
        if ((!data1.primaryKey && data1.iseditable) || !data1.is_nullable) {
            controlshtml = controlshtml + samplecontrolhtml.replaceAll("@ColumnName", alltd[0].innerText);
        }
    });
    PK = $('#TableDetails').DataTable().rows().data().filter(w => w.primaryKey == true)[0];
    if (PK) {
        tablecolumn.push({ "title": "", "data": PK.columnName, "sWidth": "50px", "sClass": "text-right ActionButton", "datatype": "actionbutton", "SqlDatatype": "actionbutton", "mRender": dataTablerender, "bVisible": true, "is_nullable": true, "primaryKey": false, "@mRender": "@dataTablerender", });

        SelectTable = $('#SelectTable').val();
        if (SelectTable.indexOf('.') > 0) {
            SelectTable = SelectTable.split('.')[1];
        }
        $('#tabs-preview').html('');
        tablestring = '<table class="table table-hover  dataTable no-footer" style="min-width: 100%; margin-left: 0px; width: auto;" role="grid" id="' + SelectTable.replace('.', '') + '"></table>';

        GetFileDetail("HtmlFiles\\DatatableExample.html", function (data) {
            if (SelectTable.indexOf('.') > 0) {
                SelectTable = SelectTable.split('.')[1];
            }
            data = data.replaceAll('@ReplaceTableHtml', tablestring)
            data = data.replaceAll('@ReplaceTableName', SelectTable.replace('.', ''))

            data = data.replaceAll('@EditDetailsSection', controlshtml)
            $('#tabs-preview').html(data.substring(data.indexOf('@StartpriviewSection') + "@StartpriviewSection".length, data.indexOf('@endpriviewSection')));
            data = data.replaceAll('@StartpriviewSection', '')
            data = data.replaceAll('@endpriviewSection', '')
            var encodedStr = data.replace(/[\u00A0-\u9999<>\&]/g, function (i) {
                return '&#' + i.charCodeAt(0) + ';';
            });
            $('#tabs-html').html('<pre><code>' + encodedStr + '</code></pre>');
            scriptName = "jsFiles\\PageSample.js";
            if (CodeSettings.ApiType == ApiType.ASHX) {
                scriptName = "jsFiles\\PageSampleRshx.js";
            }
            GetFileDetail(scriptName, function (data) {
                data = data.replaceAll("@ReplaceTableName", SelectTable);
                data = data.replaceAll("@pkColumnName", PK.columnName);
                data = data.replaceAll("@ReplaceColumns", JSON.stringify(tablecolumn).replaceAll("@mRender", "mRender").replaceAll("\"@dataTablerender\"", "dataTablerender"));
                data = data.replaceAll("@bServerSide", CodeSettings.bServerSide);
                data = data.replaceAll("@sScrollX", CodeSettings.sScrollX);
                data = data.replaceAll("@sScrollY", CodeSettings.sScrollY);
                data = data.replaceAll("@bInfo", CodeSettings.bInfo);
                data = data.replaceAll("@bSort", CodeSettings.bSort);
                data = data.replaceAll("@bPaginate", CodeSettings.bPaginate);
                data = data.replaceAll("@iDisplayLength", CodeSettings.aLengthMenu);

                if (CodeSettings.ApiType == ApiType.Controller) {
                    jsScript = data;
                    jsScript = jsScript.replaceAll("@ReplaceControllerName", "getdata");
                    $('#tabs-html').append("<script>" + jsScript + "</script>")
                }
                else {
                    GetFileDetail("jsFiles\\PageSample.js", function (jsScript) {
                        jsScript = jsScript.replaceAll("@ReplaceTableName", SelectTable);
                        jsScript = jsScript.replaceAll("@pkColumnName", PK.columnName);
                        jsScript = jsScript.replaceAll("@ReplaceColumns", JSON.stringify(tablecolumn).replaceAll("@mRender", "mRender").replaceAll("\"@dataTablerender\"", "dataTablerender"));
                        jsScript = jsScript.replaceAll("@ReplaceControllerName", "getdata");
                        $('#tabs-html').append("<script>" + jsScript + "</script>")
                    });

                }
                data = data.replaceAll("@ReplaceControllerName", SelectTable);

                $('#tabs-Js').html('<pre><code>' + data + '</code></pre>');

            });

        });

        scriptName = "classFile\\EntityController.txt";
        if (CodeSettings.ApiType == ApiType.ASHX) {
            scriptName = "classFile\\RequestData.ashx.txt";
        }
        GetbackendCode(scriptName, 'tabs-Controler');
        scriptName = "classFile\\EntityProvider.txt";
        GetbackendCode(scriptName, 'tabs-Bussiness');
        scriptName = "classFile\\DataTableSearchData.txt";
        GetbackendCode(scriptName, 'tabs-Class');

    }
    else {

        $.alert({ title: 'Error!', content: "Add a primary key to continue." });
    }

}
function GetbackendCode(scriptName, targetdiv) {
    GetFileDetail(scriptName, function (data) {

        var primaryKey = tablecolumnData.find(w => w.primaryKey)
        SelectTable = $('#SelectTable').val();
        if (SelectTable.indexOf('.') > 0)
            SelectTable = SelectTable.split('.')[1]
        if (data) {
            data = data.replaceAll('@ReplaceTableName', SelectTable);
            data = data.replaceAll('@ReplaceLowerTableName', SelectTable.toLowerCase());
            data = data.replaceAll('@ReplaceTablePK', primaryKey.columnName);
        }
        var encodedStr = data.replace(/[\u00A0-\u9999<>\&]/g, function (i) {
            return '&#' + i.charCodeAt(0) + ';';
        });
        $(targetdiv).html('<pre><code>' + encodedStr + '</code></pre>')
        $('#preloader').hide();
    });
}
var tabsStoredProcedureSetting = {
    activate: function (event, ui) {
        let scriptName = "";
        tabtype = ui.newTab.attr('tabtype');
        iscode = false;
        DatabaseType = $('#SelectDatabaseType').val();
        switch (tabtype.toString().toLowerCase()) {
            case "update":
                {
                    scriptName = "spUpdateTableData.sql";
                    break;
                }
            case "insert":
                {
                    scriptName = "spInsertTableData.sql";
                    break;
                }
            case "delete":
                {
                    scriptName = "spDeleteTableData.sql";
                    break;
                }
            case "getinfo":
                {
                    scriptName = "spGetTable.sql";
                    break;
                }
            case "getinfobyid":
                {
                    scriptName = "spGetTableDataByID.sql";
                    break;
                }
        }
        if (!iscode) {
            GetScript(DatabaseType, scriptName, function (data) {
                console.log(ui.newTab);
                let targetdiv = ui.newTab.find('a').attr('href');

                SelectTable = $('#SelectTable').val();
                if (SelectTable.indexOf('.') > 0) {
                    SelectTable = SelectTable.split('.')[1];
                }
                if (data) {
                    data = data.replaceAll('@ReplaceTableName', SelectTable);
                    data = data.replaceAll('@ReplacePROCEDUREName', SelectTable.replaceAll('.', '_'));
                }

                var primaryKey = tablecolumnData.find(w => w.primaryKey)
                switch (tabtype.toString().toLowerCase()) {
                    case "update":
                        {
                            var functionparameter = "";
                            var UpdateQueryparameter = "";
                            var wherecondition = "";
                            tablecolumnData.forEach(function (val, key) {
                                try {
                                    //debugger;
                                    if (primaryKey.columnName == val.columnName) {
                                        wherecondition = "where " + val.columnName + "=@" + val.columnName + "";
                                    }
                                    else {
                                        UpdateQueryparameter = ((UpdateQueryparameter != '') ? UpdateQueryparameter + ",\n" : '') + val.columnName + ' = @' + val.columnName;
                                    }
                                    functionparameter = ((key != 0) ? functionparameter + ",\n" : '') + "@" + val.columnName + ' as ' + val.datatype1 + (val.datatype1 == 'varchar' || val.datatype1 == 'nvarchar' ? '(500)' : '');
                                    if (key == tablecolumnData.length - 1) {
                                        data = data.replaceAll('@ReplaceParameter', functionparameter);
                                        data = data.replaceAll('@ReplaceUpdateParameter', UpdateQueryparameter);
                                        data = data.replaceAll('@Replacewherecondition', wherecondition);
                                    }
                                }
                                catch (e) {
                                    debugger;
                                    console.log(e.message);
                                }
                            });
                            break;
                        }
                    case "insert":
                        {
                            var functionparameter = "";
                            var ReplaceInsertColumn = "";
                            var ReplaceInsertParameter = "";
                            var wherecondition = "";
                            tablecolumnData.forEach(function (val, key) {
                                //debugger
                                if (val.iseditable) {
                                    ReplaceInsertColumn = ((ReplaceInsertColumn != '') ? ReplaceInsertColumn + ",\n" : '') + val.columnName;
                                }
                                if (val.iseditable) {
                                    ReplaceInsertParameter = ((ReplaceInsertParameter != '') ? ReplaceInsertParameter + ",\n" : '') + '@' + val.columnName;
                                }
                                functionparameter = ((key != 0) ? functionparameter + ",\n" : '') + "@" + val.columnName + ' as ' + val.datatype1 + (val.datatype1 == 'varchar' ? '(500)' : '');
                                if (key == tablecolumnData.length - 1) {
                                    data = data.replaceAll('@ReplaceParameter', functionparameter);
                                    data = data.replaceAll('@ReplaceInsertColumn', ReplaceInsertColumn);
                                    data = data.replaceAll('@ReplaceInsertParameter', ReplaceInsertParameter);
                                }
                            });
                            break;
                        }
                    case "delete":
                        {
                            if (primaryKey) {
                                wherecondition = "where " + primaryKey.columnName + "=@" + primaryKey.columnName + "";
                                functionparameter = "@" + primaryKey.columnName + ' as ' + primaryKey.datatype1 + (primaryKey.datatype1 == 'varchar' ? '(500)' : '');
                                data = data.replaceAll('@Replacewherecondition', wherecondition);
                                data = data.replaceAll('@ReplaceParameter', functionparameter);

                            }
                            break;
                        }
                    case "getinfo":
                        {
                            scriptName = "GetTableData.sql";
                            break;
                        }
                    case "getinfobyid":
                        {
                            if (primaryKey) {
                                wherecondition = "where " + primaryKey.columnName + "=@" + primaryKey.columnName + "";
                                functionparameter = "@" + primaryKey.columnName + ' as ' + primaryKey.datatype1 + (primaryKey.datatype1 == 'varchar' ? '(500)' : '');
                                data = data.replaceAll('@Replacewherecondition', wherecondition);
                                data = data.replaceAll('@ReplaceParameter', functionparameter);

                            }
                            break;
                        }
                }

                $(targetdiv).html('<pre><code>' + data + '</code></pre>')
                $('#preloader').hide();
            });
        }




        //alert(ui.index);
    }
}


var tabsFunctionsSetting = {
    activate: function (event, ui) {
        let scriptName = "";
        tabtype = ui.newTab.attr('tabtype');

        switch (tabtype.toString().toLowerCase()) {
            case "controler":
                {
                    scriptName = "classFile\\EntityController.txt";
                    if (CodeSettings.ApiType == ApiType.ASHX) {
                        scriptName = "classFile\\RequestData.ashx.txt";
                    }
                    break;
                }
            case "bussiness":
                {
                    scriptName = "classFile\\EntityProvider.txt";
                    break;
                }
            case "class":
                {
                    scriptName = "classFile\\DataTableSearchData.txt";
                    break;
                }
        }

        DatabaseType = $('#SelectDatabaseType').val();
        GetFileDetail(scriptName, function (data) {
            console.log(ui.newTab);
            let targetdiv = ui.newTab.find('a').attr('href');

            var primaryKey = tablecolumnData.find(w => w.primaryKey)
            SelectTable = $('#SelectTable').val();
            if (SelectTable.indexOf('.') > 0) {
                SelectTable = SelectTable.split('.')[1];
            }
            if (data) {
                data = data.replaceAll('@ReplaceTableName', SelectTable);
                data = data.replaceAll('@ReplaceLowerTableName', SelectTable.toLowerCase());
                data = data.replaceAll('@ReplaceTablePK', primaryKey.columnName);
            }

            switch (tabtype.toString().toLowerCase()) {
                case "Controler":
                    {
                        break;
                    }
                case "Bussiness":
                    {


                        break;
                    }
                case "Class":
                    {
                        break;
                    }
            }
            var encodedStr = data.replace(/[\u00A0-\u9999<>\&]/g, function (i) {
                return '&#' + i.charCodeAt(0) + ';';
            });
            $(targetdiv).html('<pre><code>' + encodedStr + '</code></pre>')
            $('#preloader').hide();
        });



        //alert(ui.index);
    }
}
function copyToClipboard(ctrl) {
    if ($("#" + ctrl + " li.ui-state-active a").attr('href') == "tabs-preview" || $("#" + ctrl + " li.ui-state-active a").attr('href') == "tabs-Links") {
        return;
    }
    var copyText = $($("#" + ctrl + " li.ui-state-active a").attr('href')).text()

    // Copy the text inside the text field
    navigator.clipboard.writeText(copyText);
}
function hideShowSettingModal(show) {
    if (show) {
        $('#SettingModal').show();
    }
    else {
        $('#SettingModal').hide();
    }
}
function saveSettings() {
    CodeSettings = {
        "ApiType": $('#SelectApiType').val(),
        "GridType": $('#SelectGridType').val(),
        "bSort": $('#DTE_Sorting')[0].checked,
        "searching": $('#DTE_Searching')[0].checked,
        "bServerSide": $('#DTE_bServerSide')[0].checked,
        "bInfo": $('#DTE_bInfo')[0].checked,
        "sScrollX": $('#DTE_ScrollX')[0].checked,
        "sScrollY": $('#DTE_ScrollY')[0].checked,
        "bPaginate": $('#DTE_Paginate')[0].checked,
        "aLengthMenu": $('#aLengthMenu').val(),
    }
    hideShowSettingModal(false);
} var ApiType = [];
function bindApiType() {
    ApiType = GetApiList();
    bindSelect(ApiType, '#SelectApiType', null, 1);
}

$('.accordion-prev').click(function (a, b) {
    $($(a.currentTarget).attr('next-step')).click();
    step = "1";
    step = $(a.currentTarget).attr('step')
    switch (step) {
        case "Dbconnection":
            {

            }
            break;
        case "TableSelection":
            {
                $('#preloader').show();
                $('.accordion-Dbconnection').show();
                $('.accordion-TableSelection').hide();
                setTimeout(function () {
                    $('#preloader').hide();
                }, 1000);
            }
            break;
        case "FilterOptions":
            {
                $('.accordion-TableSelection').show();
                $('.accordion-headingFilterOptions').hide();

            }
            break;
        case "headingFrontend":
            {
                $('.accordion-TableSelection').show();
                $('.accordion-Frontend').hide();
            }
            break;
        case "headingUSPSelection":
            {
                $('.accordion-StoredProcedure').hide();
                $('.accordion-Frontend').show();
            }
            break;
    }
});
$('.accordion-next').click(function (a, b) {
    step = "1";
    step = $(a.currentTarget).attr('step')
    switch (step) {
        case "Dbconnection":
            {
                ConnectDatabase(true);
            }
            break;
        case "TableSelection":
            {
                var result = true;

                if ($('#selectDatabase').val() == "0") {
                    result = false;
                    $('#selectDatabase').addClass("text-danger is-invalid");
                    $('#selectDatabase').attr('title', 'Select Database')
                }
                else {
                    $('#selectDatabase').removeClass("text-danger is-invalid");
                    $('#selectDatabase').attr('title', '')
                }
                if ($('#SelectTable').val() == "0") {
                    result = false;
                    $('#SelectTable').addClass("text-danger is-invalid");
                    $('#SelectTable').attr('title', 'Select Table')
                }
                else {
                    $('#SelectTable').removeClass("text-danger is-invalid");
                    $('#SelectTable').attr('title', '')
                }
                if (result) {
                    $('.accordion-TableSelection').hide();
                    $('.accordion-headingFilterOptions').show();
                    saveSettings();
                    bindTableDetails();
                }
            }
            break;
        case "FilterOptions":
            {
                GenerateCode();
                $('.accordion-headingFilterOptions').hide();
                $('.accordion-Frontend').show();
            }
            break;
        case "headingFrontend":
            {                
                $('.accordion-StoredProcedure').show();
                $('.accordion-Frontend').hide();
            }
            break;
    }


});

function ConnectDatabase(movetoNext) {
    if (canConnectDatabase()) {
        DatabaseType = $('#SelectDatabaseType').val();
        txtServerName = $('#txtServerName').val();
        textUserName = $('#textUserName').val();
        textPassword = $('#textPassword').val();
        $('#preloader').show();
        GetDatabases(DatabaseType, txtServerName, textUserName, textPassword, function (data) {
            if (!data.isError) {
                bindSelect(data.data, '#selectDatabase', { "Select Database": 0 }, 'rawdata_drchrono');
                $('#selectDatabase').change();
                //$('#headingTableSelection button').attr('disabled', false);

                if (movetoNext) {                   
                    $('.accordion-Dbconnection').hide();
                    $('.accordion-TableSelection').show();
                }
                //$('#headingFilterOptions button').attr('disabled', false);
            }
            else {
                bindSelect([], '#selectDatabase', { "Select Database": 0 }, 0);
                bindSelect([], '#SelectTable', { "Select Table": 0 }, 0);
                $.alert({ title: 'Error!', content: data.error });
            }
            $('#preloader').hide();
        });
    }
}

function bindTableDetails() {
    DatabaseType = $('#SelectDatabaseType').val();
    txtServerName = $('#txtServerName').val();
    textUserName = $('#textUserName').val();
    textPassword = $('#textPassword').val();
    textDatabase = $('#selectDatabase').val();
    SelectTable = $('#SelectTable').val();
    $('#preloader').show();
    GetTableDetails(DatabaseType, txtServerName, textUserName, textPassword, textDatabase, SelectTable, function (data) {
        tablecolumnData = data.data;
        $('#preloader').hide();
        if (!data.error) {
            data = data.data;
            for (i = 0; i < data.length; i++) {
                data[i]["SqlDatatype"] = SqlToDtDataTypeMaping[data[i].datatype1];
                if (data[i].columnName == "IsActive") {
                    data[i]["SqlDatatype"] = "bit";
                }
                else if (data[i].columnName.indexOf("Allow") > -1) {
                    data[i]["SqlDatatype"] = "bit";
                }
                else if (data[i].columnName.indexOf("Password") > -1 && data[i].columnName.indexOf("Is") < 0) {
                    data[i]["SqlDatatype"] = "Password";
                }
                else if (data[i].columnName.indexOf("Password") > -1 && data[i].columnName.indexOf("Is") >= 0) {
                    data[i]["SqlDatatype"] = "bit";
                }
                else if (data[i].columnName.indexOf("Phone") > -1) {
                    data[i]["SqlDatatype"] = "Phone";
                }
                else if (data[i].columnName.indexOf("Email") > -1) {
                    data[i]["SqlDatatype"] = "Email";
                }
            }
            $('#TableDetails').find('tr').remove().end();
            tblMyTable_columns = [
                { ajaxData: "columnName", title: "Column Name", data: "columnName", "sWidth": "100px", "min-width": "100px", "sClass": "text-right columnName", "mData": "columnName", datatype: "text", mRender: dataTablerender },
                { ajaxData: "datatype1", title: "Data Type", data: "SqlDatatype", "sWidth": "20px", "min-width": "20px", datatype: "datatype1", "sClass": "batcher datatype1", bVisible: true, mRender: dataTablerender },
                { ajaxData: "is_nullable", title: "Nullable", data: "is_nullable", "sWidth": "20px", "min-width": "20px", datatype: "checkbox", "sClass": "batcher is_nullable", mRender: dataTablerender },
                { ajaxData: "max_length", title: "Max Length", data: "max_length", "sWidth": "20px", "min-width": "20px", datatype: "integer", "sClass": "batcher max_length", bVisible: false, mRender: dataTablerender },
                { ajaxData: "IsVisibale", title: "Visibale", data: "isVisibale", "sWidth": "20px", "min-width": "20px", datatype: "checkbox", "sClass": "batcher IsVisibale", mRender: dataTablerender },
                { ajaxData: "allowfiltering", title: "Allow Filter", data: "allowfiltering", "sWidth": "20px", "min-width": "20px", datatype: "checkbox", "sClass": "batcher allowfiltering", mRender: dataTablerender },
                { ajaxData: "iseditable", title: "Allow Edit", data: "iseditable", "sWidth": "20px", "min-width": "20px", datatype: "checkbox", "sClass": "batcher allowfiltering", mRender: dataTablerender }
            ]
            $('#TableDetails').DataTable({
                "serverSide": false,
                "searching": false,
                "scrollX": false,
                "scrollY": '400px',
                "scrollCollapse": false,
                "paging": false,
                "pagingType": "full_numbers",
                "ordering": false,
                "autoWidth": true,
                sServerMethod: 'GET',
                destroy: true,
                responsive: false,
                "info": false,
                "pageLength": 25,
                "lengthMenu": [25, 50, 75, 100, 200, 500, 1000],
                stateSave: false,
                fixedColumns: true,
                fixedColumns: {
                    leftColumns: 1
                },
                dom: 'Blfrtip',
                buttons: ['colvis'],
                deferRender: true,
                columns: tblMyTable_columns,
                data: data,
                rowId: 'column_id'
            });
        }
        else {
            $.alert({ title: 'Error!', content: data.error });
        }
        //bindSelect(data, '#SelectTable', { "Select Table": 0 }, 0);
    });
}
