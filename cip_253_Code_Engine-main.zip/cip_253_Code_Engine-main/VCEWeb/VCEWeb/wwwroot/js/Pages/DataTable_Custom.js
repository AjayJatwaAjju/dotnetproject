﻿const SqlToDtDataTypeMaping = {
    date: "date",
    datetime2: "date",
    datetime: "date",
    decimal: "number",
    usdcurrency: "usdcurrency",
    checkbox: "checkbox",
    drop_down: "drop_down",
    blankcheckbox: "blankcheckbox",
    uniqueidentifier: "text",
    varchar: "text",
    nvarchar: "text",
    int: "integer",
    bit: "bit",
    char: "text",
    Password: "Password",
    Phone: "Phone",
    Email: "Email",
    hidden: "hidden",
    bigint: "integer",
    "character varying": "text",
    "integer": "integer",
    "timestamp without time zone": "datetime",
    "text": "text",
    "smallint": "integer",
};


let SqlToDtDataTypeMapingList = {};

$.each(SqlToDtDataTypeMaping, function (data, key) {
    SqlToDtDataTypeMapingList[key] = key;
    //debugger;
})
const DatatableDataType = {
    date: "date",
    number: "number",
    usdcurrency: "usdcurrency",
    checkbox: "checkbox",
    drop_down: "drop_down",
    blankcheckbox: "blankcheckbox",
    integer: "integer",
    bit: "bit",
    actionbutton: "actionbutton",
    datatype1: "datatype1",
};

dataTablerender = function (data, type, full, indx) {
    var datatype = indx.settings.aoColumns[indx.col].datatype;
    var cdata = indx.settings.aoColumns[indx.col].data;
    var sClass = indx.settings.aoColumns[indx.col].sClass;
    var rowId = full[indx.settings.rowId];
    if (data == undefined || data == null) { data = ""; }
    var calhtml = data;
    //return calhtml;
    switch (datatype) {
        case DatatableDataType.date:
            {
                if (data != "" && data != "1900-01-01T00:00:00") {
                    data = FormateDate(data, 1);

                } else {
                    data = "";
                }
                calhtml = data;
                //$('#' + inputID + '_' + checkiboxid).inputmask("99/99/9999");
                break;
            }
        case DatatableDataType.number:
            {
                if (data != "") {
                    data = '$' + Numberformat(data, '', 2);
                } else if (parseFloat(data) == 0) {
                    data = '$' + Numberformat(00, '', 2);
                } else {
                    data = "";
                }
                calhtml = data;
                break;
            }
        case DatatableDataType.integer:
            {
                if (data != "") {
                    data = Numberformat(data, '', 0);
                } else if (parseFloat(data) == 0) {
                    data = Numberformat(00, '', 0);
                } else {
                    data = "";
                }
                calhtml = data;
                break;
            }
        case DatatableDataType.usdcurrency:
            {
                if (data != "") {
                    data = '$' + Numberformat(data, '', 2);
                } else if (parseFloat(data) == 0) {
                    data = '$' + Numberformat(00, '', 2);
                } else {
                    data = "";
                }
                calhtml = data;
                break;
            }
        case DatatableDataType.checkbox:
            {
                calhtml = '<div id="divcheckbox_' + cdata + '" class="text"  ><input type="checkbox" ' + ((data == 'True' || data) ? 'checked' : '') + ' id="Checkbox_' + cdata + '" /></div>';
                break;
            }
        case DatatableDataType.datatype1:
            {
                calhtml = '<div id="divcheckbox_' + cdata + '" class="text"  ><Select id="' + rowId +'dataTypes" class="form-control"></select></div>';
                bindSelect(SqlToDtDataTypeMapingList, '#' + rowId +'dataTypes', { "Select Type": 0 }, data);
                break;
            }
        case DatatableDataType.blankcheckbox:
            {
                calhtml = '<div id="divcheckbox_' + rowId + '" class="text"  ><input type="checkbox" id="Checkbox_' + rowId + '" onclick="checkUncheck(this)" /></div>';
                break;
            }
        case DatatableDataType.drop_down:
            {
                calhtml = data;
            }
            break;
        case DatatableDataType.actionbutton:
            {
                //debugger;
                calhtml = '<a onClick="editEntity(\'' + data + '\')" class="editEntity"><i class="fa fa-edit"></i></a><a onClick="deleteEntity(\'' + data + '\')" class="deleteEntity"><i class="fa fa-trash"></i></a>';
            }
            break;
        case DatatableDataType.integer:
            {
                if (data == "1") {
                    data = 'True';
                }
                else {
                    data = "False";
                }
                calhtml = data;
                break;
            }
            break;
    }
    return calhtml;
}

FormateDate = function (date, Mode) {
    if (date == null || date == "Invalid date" || date == "") {
        return "";
    }

    switch (Mode) {
        case 1:
            date = new Date(date);
            var vDate = date.getDate();
            var vMonth = (date.getMonth() + 1);
            date = ((vMonth < 10 ? '0' + vMonth : vMonth) + '/' + (vDate < 10 ? '0' + vDate : vDate) + '/' + date.getFullYear());
            break;
        case 2:
            date = new Date(date);
            var vDate = date.getDate();
            var vMonth = (date.getMonth() + 1);
            date = ((vMonth < 10 ? '0' + vMonth : vMonth) + '/' + (vDate < 10 ? '0' + vDate : vDate) + '/' + date.getFullYear());
            break;
        case 3:
            date = new Date(date);
            var vDate = date.getDate();
            var vMonth = (date.getMonth() + 1);
            date = (date.getFullYear() + '/' + (vMonth < 10 ? '0' + vMonth : vMonth) + '/' + (vDate < 10 ? '0' + vDate : vDate));
            break;
        case 4:
            date = new Date(date);
            var vDate = date.getDate();
            var vMonth = (date.getMonth() + 1);
            date = (date.getFullYear() + '-' + (vMonth < 10 ? '0' + vMonth : vMonth) + '-' + (vDate < 10 ? '0' + vDate : vDate));
            break;
    }
    return date;
}
function Numberformat(num, prifix, decimalplace) {
    //    if (num == "")
    //        return "-";
    if (prifix == undefined || prifix == null) prifix = "";
    var postfix = "";
    if (num < 0) {
        prifix = '(' + prifix;
        postfix = ")"
    }
    if (num == '.0' || num == '.') {
        num = '0.0';
    }
    var p = parseFloat(num).toFixed(decimalplace).split(".");
    if (decimalplace == null || decimalplace == undefined) {
        p = num.toString().split('.')
        return prifix + p[0].split("").reverse().reduce(function (acc, num, i, orig) {
            return num == "-" ? acc : num + (i && !(i % 3) ? "," : "") + acc;
        }, "") + postfix;
    }
    else if (decimalplace == 0) {
        p = num.toString().split('.')[0]
        return prifix + parseInt(num) + postfix;
    }
    else {
        //p = num.toString().split('.')
        return prifix + p[0].split("").reverse().reduce(function (acc, num, i, orig) {
            return num == "-" ? acc : num + (i && !(i % 3) ? "," : "") + acc;
        }, "") + "." + p[1] + postfix;
    }

}
function AllowNumeric(ctrl) {
    $("#" + ctrl.id).bind("keypress", function (event) {
        if (event.charCode != 0) {
            var regex;
            regex = new RegExp("^[0-9 ]+$");
            var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            if (!regex.test(key)) {
                event.preventDefault();
                return false;
            }
        }
    });
}
function validateFloatKeyPress(el, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    var number = el.value.split('.');


    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 45) {
        return false;
    }
    //just one dot (thanks ddlab)
    if (number.length > 1 && charCode == 46) {
        return false;
    }
    if (el.value.length != 0 && charCode == 45) {
        return false;
    }
    //get the carat position
    var caratPos = getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && (number[1].length > 1)) {
        return false;
    }
    //if ((number[0].length >= 38)&&number.length>2) {
    //    return false;
    //}
    return true;
}
function getSelectionStart(o) {
    if (o.createTextRange) {
        var r = document.selection.createRange().duplicate()
        r.moveEnd('character', o.value.length)
        if (r.text == '') return o.value.length
        return o.value.lastIndexOf(r.text)
    } else return o.selectionStart
}
function UnNumberformat(number, prifix) {
    try {
        if (number) {
            if (number.toString().indexOf("(") > -1) {
                return parseFloat("-" + number.toString().replace(prifix, '').replace(/,/g, "").replace('(', '').replace(')', ''));
            }
            else
                return parseFloat(number.toString().replace(prifix, '').replace(/,/g, ""));
        }
        else {
            return "";
        }
    }
    catch (ex) {
        return 0;
    }
}
function UnIntegerformat(number, prifix) {
    try {
        if (number) {
            if (number.toString().indexOf("(") > -1) {
                return parseInt("-" + number.toString().replace(prifix, '').replace(/,/g, "").replace('(', '').replace(')', ''));
            }
            else
                return parseInt(number.toString().replace(prifix, '').replace(/,/g, ""));
        }
        else {
            return "";
        }
    }
    catch (ex) {
        return 0;
    }
}
function validateFloatKeyPress(el, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    var number = el.value.split('.');


    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 45) {
        return false;
    }
    //just one dot (thanks ddlab)
    if (number.length > 1 && charCode == 46) {
        return false;
    }
    if (el.value.length != 0 && charCode == 45) {
        return false;
    }
    //get the carat position
    var caratPos = getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && (number[1].length > 1)) {
        return false;
    }
    //if ((number[0].length >= 38)&&number.length>2) {
    //    return false;
    //}
    return true;
}
function ChangeCurrecyFormatOnFocus(ctrl, prifix) {
    if ($('#' + ctrl.id).val() != "")
        $('#' + ctrl.id).val(UnNumberformat($('#' + ctrl.id).val(), prifix));
}


function IsValidPhone(phone) {
    if (phone.trim() != '') {
        var filter = /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;
        return filter.test(phone);
    }
    else
        return true;// returns boolean
}
function IsValidEmail(Email) {
    if (Email.trim() != '') {
        var filter = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return filter.test(Email);
    }
    else
        return true;// returns boolean
}