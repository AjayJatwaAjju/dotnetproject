﻿const DatatableDataType ={
    date = "date",
    number = "number",
    usdcurrency = "usdcurrency",
    checkbox = "checkbox",
    drop_down = "drop_down",
    integer = "integer",
}