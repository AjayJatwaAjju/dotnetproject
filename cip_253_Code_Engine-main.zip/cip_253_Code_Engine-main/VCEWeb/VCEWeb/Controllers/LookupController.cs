﻿using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebHttp = System.Web.Http;
using VCEWeb.Services;
using System.Data;
using VCEWeb.Models;
using VCE.DAL;

namespace VCEWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [WebHttp.Authorize]
    public class LookupController : ControllerBase
    {
        [EnableQuery]
        [Route("DatabaseTypes")]
        [WebHttp.Authorize]
        public virtual IActionResult Get()
        {
            LookupService lookupService = new LookupService();
            var output = lookupService.GetDatabaseTypes().Result;
            return Ok(output);
        }

        [EnableQuery]
        [Route("DatabasesOld")]
        public async virtual Task<ActionResult> Get(string DatabaseType, string DataSource, String UserName, string UserPassword)
        {
            try
            {

                LookupService lookupService = new LookupService();
                var output = await lookupService.GetDatabases(DatabaseType, DataSource, UserName, UserPassword);
                OutputDetails outputDetails = new OutputDetails();
                outputDetails.isError = false;
                outputDetails.Error = "";
                outputDetails.data = output;
                return Ok(outputDetails);
            }
            catch (Exception ex)
            {
                OutputDetails error = new OutputDetails();
                error.isError = true;
                error.Error = ex.Message;
                //error.data = ex;
                return Ok(error);
            }
        }
        [EnableQuery]
        [Route("Databases")]
        public async virtual Task<ActionResult> GetDatabases(string DatabaseType)
        {
            try
            {
                string connectionstring = Request.Headers["UTI5dWJtVmpkR2x2YmxOMGNtbHVadz09"].ToString();

                LookupService lookupService = new LookupService();
                var output = await lookupService.GetDatabases(DatabaseType, connectionstring); ;
                OutputDetails outputDetails = new OutputDetails();
                outputDetails.isError = false;
                outputDetails.Error = "";
                outputDetails.data = output;
                return Ok(outputDetails);
            }
            catch (Exception ex)
            {
                OutputDetails error = new OutputDetails();
                error.isError = true;
                error.Error = ex.Message;
                //error.data = ex;
                return Ok(error);
            }
        }
        [EnableQuery]
        [Route("TableList")]
        public async virtual Task<ActionResult> GetTableList(string DatabaseType)
        {
            try
            {
                string connectionstring = Request.Headers["UTI5dWJtVmpkR2x2YmxOMGNtbHVadz09"].ToString();

                LookupService lookupService = new LookupService();
                var output = await lookupService.GetTableList(DatabaseType, connectionstring);                
                OutputDetails outputDetails = new OutputDetails();
                outputDetails.isError = false;
                outputDetails.Error = "";
                outputDetails.data = output;
                return Ok(outputDetails);
            }
            catch (Exception ex)
            {
                OutputDetails error = new OutputDetails();
                error.isError = true;
                error.Error = ex.Message;
                //error.data = ex;
                return Ok(error);
            }
        }
        [EnableQuery]
        [Route("TableDetail")]
        public async virtual Task<object> GetTableDetails(string DatabaseType, string TableName)
        {
            try
            {
                string connectionstring = Request.Headers["UTI5dWJtVmpkR2x2YmxOMGNtbHVadz09"].ToString();
                LookupService lookupService = new LookupService();
                var output = await lookupService.GetTableDetails(DatabaseType, connectionstring, TableName);

                HttpContext.Session.SetString("connectionstring", connectionstring);
                HttpContext.Session.SetString("DatabaseType", DatabaseType);
                var columneList = (from DataRow dr in output.Rows
                                   select new
                                   {
                                       column_id = dr["column_id"].ToString(),
                                       ColumnName = dr["ColumnName"].ToString(),
                                       Datatype1 = dr["Datatype1"].ToString(),
                                       max_length = dr["MaxLength"].ToString(),
                                       is_nullable = Convert.ToBoolean(dr["is_nullable"].ToString()),
                                       PrimaryKey = Convert.ToBoolean(dr["PrimaryKey"].ToString()),
                                       scale = dr["scale"].ToString(),
                                       IsVisibale = Convert.ToBoolean(dr["IsVisibale"].ToString()),
                                       allowfiltering = Convert.ToBoolean(dr["allowfiltering"].ToString()),
                                       Iseditable = Convert.ToBoolean(dr["Iseditable"].ToString()),
                                   }).ToList();

                OutputDetails outputDetails = new OutputDetails();
                outputDetails.isError = false;
                outputDetails.Error = "";
                outputDetails.data = columneList;
                return Ok(outputDetails);
            }
            catch (Exception ex)
            {
                OutputDetails error = new OutputDetails();
                error.isError = true;
                error.Error = ex.Message;
                //error.data = ex;
                return Ok(error);
            }
        }
    }
}
