﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data;
using VCE.Business.Repository;
using VCE.DAL;
using VCEWeb.Models;
using VCEWeb.Services;

namespace VCEWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetDataController : ControllerBase
    {
        [HttpGet]
        public async virtual Task<object> Get()
        {
            var output = "";
            return Ok(output);
        }
        [HttpGet("id")]
        public async virtual Task<object> Get(string Id)
        {
            var output = "";
            return Ok(output);
        }
        [HttpPost]
        public async virtual Task<object> POST([FromBody] object JsonObject)
        {
            var output = "";
            return Ok(JsonObject);
        }
        [HttpPut]
        public async virtual Task<object> Put(string JsonObject)
        {
            var output = "";
            return Ok(output);
        }
        [HttpDelete("id")]
        public async virtual Task<object> Delete(string id)
        {
            var output = "";
            return Ok(output);
        }
        [HttpPatch]
        public async virtual Task<object> Patch(string JsonObject)
        {
            var output = "";
            return Ok(output);
        }
        [HttpPost]
        [Route("getfiltereddata")]
        public async virtual Task<object> GetTableData(DataTableSearchData Data)
        {
            LookupService lookupService = new LookupService();
            string connectionstring = HttpContext.Session.GetString("connectionstring");
            string DatabaseType = HttpContext.Session.GetString("DatabaseType");
            var dataTableOutput = new DataTableOutput();
            string whereCondition = "";
            string orderBy = "";
            foreach (var a in Data.columns)
            {
                //if (!string.IsNullOrEmpty(a.search.value))
                {
                    if (DatabaseType == "1")
                        whereCondition = whereCondition + ((!string.IsNullOrEmpty(whereCondition)) ? " or " : "") + a.data + " like '%" + a.search.value + "%'";
                    else
                    {
                        whereCondition = whereCondition + "\n or cast(basetable.\"" + a.data + "\"  as CHARACTER VARYING) like '%'||fltr.search||'%'";
                    }
                }
            }
            foreach (var a in Data.order)
            {
                orderBy = Data.columns[a.column].data + " " + a.dir;
                //column
            }
            string pageSize = Data.length.ToString();
            string pageStart = Data.start.ToString();
             
            var output = await lookupService.GetTableData(Data.TableName, connectionstring, whereCondition, orderBy, pageSize, pageStart, DatabaseType, Data);
            dataTableOutput.data = JsonConvert.SerializeObject(output);
            return dataTableOutput;
        }
        [HttpGet]
        [Route("Scriptfile")]
        public async virtual Task<object> GetScript(string DatabaseType, string FileName)
        {
            LookupService lookupService = new LookupService();
            var output = await lookupService.GetScript(DatabaseType, FileName);
            return output;
        }
        [HttpGet]
        [Route("FileString")]
        public async virtual Task<object> GetFileString(string FileName)
        {
            LookupService lookupService = new LookupService();
            var output = await lookupService.GetFileString(FileName);
            return output;
        }
    }
}
