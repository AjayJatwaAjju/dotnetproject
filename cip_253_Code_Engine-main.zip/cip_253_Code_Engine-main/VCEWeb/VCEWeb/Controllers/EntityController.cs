﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data;
using VCE.DAL;
using VCEWeb.Models;

namespace VCEWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EntityController : ControllerBase
    {
        [HttpPost]
        [Route("getfiltereddata")]
        public async virtual Task<object> GetTableData(DataTableSearchData Data)
        {
            EntityProvider p = new EntityProvider();
            var dataTableOutput = new DataTableOutput();
            string whereCondition = "";
            string orderBy = "";
            foreach (var a in Data.columns)
            {
                if (!string.IsNullOrEmpty(a.search.value))
                {
                    whereCondition = whereCondition + ((!string.IsNullOrEmpty(whereCondition)) ? " or " : "") + a.data + " like '%" + a.search.value + "%'";
                }
            }
            foreach (var a in Data.order)
            {
                orderBy = Data.columns[a.column].data + " " + a.dir;
                //column
            }
            string pageSize = Data.length.ToString();
            string pageStart = Data.start.ToString();
            var output = p.GetUserInfo(whereCondition, orderBy, pageSize, pageStart);
            dataTableOutput.data = JsonConvert.SerializeObject(output);
            return dataTableOutput;
        }
        [HttpGet("id")]
        public async virtual Task<object> Get(string Id)
        {
            EntityProvider p = new EntityProvider();
            var data = p.GetUserInfoById(Id);
            return Ok(data);
        }
        [HttpPost]
        public async virtual Task<object> POST([FromBody]  DataTable JsonObject)
        {
            EntityProvider p = new EntityProvider();
            var data = p.Insert(JsonObject);
            return Ok(data);
        }
        [HttpPut]
        public async virtual Task<object> Put([FromBody] DataTable JsonObject)
        {
            EntityProvider p = new EntityProvider();
            var data = p.Update(JsonObject);
            return Ok(data);
        }
        [HttpDelete("id")]
        public async virtual Task<object> Delete(string id)
        {
            EntityProvider p = new EntityProvider();
            var data = p.Delete(id);
            return Ok(data);
        }

    }
}
