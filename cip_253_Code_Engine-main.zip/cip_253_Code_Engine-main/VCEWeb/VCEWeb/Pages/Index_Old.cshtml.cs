﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace VCEWeb.Pages
{
    public class IndexModel_Old : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel_Old(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }
    }
}