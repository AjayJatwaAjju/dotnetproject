﻿using System.Data;
using VCE.Business.Repository;
using VCE.DAL;
using VCEWeb.Models;

namespace VCEWeb.Services
{
    public class LookupService
    {
        public async virtual Task<IDictionary<string, int>> GetDatabaseTypes()
        {
            LookupRepository lookupRepository = new LookupRepository();
            var output = await lookupRepository.GetDatabaseTypes();
            return output;
        }
        public async virtual Task<IDictionary<string, string>> GetDatabases(string DatabaseType, string DataSource, String UserName, string UserPassword, string Database = "master")
        {
            LookupRepository lookupRepository = new LookupRepository();
            var output = await lookupRepository.GetDatabases(DatabaseType, DataSource, UserName, UserPassword, Database); 
            return output;
        }
        public async virtual Task<IDictionary<string, string>> GetDatabases(string DatabaseType, string connectionstring)
        {
            LookupRepository lookupRepository = new LookupRepository();
            var output = await lookupRepository.GetDatabases(DatabaseType, connectionstring);
            return output;
        }
        public async virtual Task<IDictionary<string, string>> GetTableList(string DatabaseType, string connectionstring)
        {
            LookupRepository lookupRepository = new LookupRepository();
            var output = await lookupRepository.GetTableList(DatabaseType, connectionstring);
            return output;
        }
        public async virtual Task<DataTable> GetTableDetails(string DatabaseType, string connectionstring, string TableName)
        {
            LookupRepository lookupRepository = new LookupRepository();
            var output = await lookupRepository.GetTableDetails(DatabaseType, connectionstring, TableName);
            return output;
        }
        public async virtual Task<DataTable> GetTableData(string TableName, string connectionstring, string whereCondition, string orderBy, string pageSize, string pageStart,string DatabaseType, DataTableSearchData inputjson)
        {
            LookupRepository lookupRepository = new LookupRepository();
            var output = await lookupRepository.GetTableData(TableName, connectionstring, whereCondition, orderBy, pageSize, pageStart,  DatabaseType, inputjson);
            return output;
        }
        public async virtual Task<string> GetScript(string Databasetype, string FileName)
        {
            LookupRepository lookupRepository = new LookupRepository();
            var result = await lookupRepository.GetScript(Databasetype, FileName);

            return result;
        }
        public async virtual Task<string> GetFileString(string FileName)
        {
            LookupRepository lookupRepository = new LookupRepository();
            var result = await lookupRepository.GetFileString(FileName);

            return result;
        }
    }
}
